#!/bin/bash
../local/bin/sox --no-show-progress -t raw -e signed -b 16 -c 2 -r 44100 - -d