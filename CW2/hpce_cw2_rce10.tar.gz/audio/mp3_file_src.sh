#!/bin/bash
../local/bin/lame --mp3input --decode --silent -t $1 -