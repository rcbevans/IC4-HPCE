//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by acm.rc
//
#define IDI_ICON                        101
#define IDD_CONFIG                      102
#define IDD_ABOUT                       103
#define IDC_STATIC_DECODING             1000
#define IDC_CHECK_COPYRIGHT             1001
#define IDC_CHECK_CHECKSUM              1002
#define IDC_CHECK_ORIGINAL              1003
#define IDC_CHECK_PRIVATE               1004
#define IDC_COMBO_ENC_STEREO            1005
#define IDC_CHECK_ENC_SMART             1006
#define IDC_STATIC_ENC_ICON             1007
#define IDC_STATIC_ABOUT_TITLE          1008
#define IDC_STATIC_ABOUT_URL            1009
#define IDC_STATIC_CONFIG_VERSION       1010
#define IDC_CHECK_ENC_ABR               1011
#define IDC_SLIDER_AVERAGE_MIN          1012
#define IDC_SLIDER_AVERAGE_MAX          1013
#define IDC_SLIDER_AVERAGE_STEP         1014
#define IDC_SLIDER_AVERAGE_SAMPLE       1015
#define IDC_STATIC_AVERAGE_MIN          1016
#define IDC_STATIC_AVERAGE_MAX          1017
#define IDC_STATIC_AVERAGE_STEP         1018
#define IDC_STATIC_AVERAGE_SAMPLE       1019
#define IDC_STATIC_AVERAGE_MIN_VALUE    1020
#define IDC_STATIC_AVERAGE_MAX_VALUE    1021
#define IDC_STATIC_AVERAGE_STEP_VALUE   1022
#define IDC_STATIC_AVERAGE_SAMPLE_VALUE 1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
